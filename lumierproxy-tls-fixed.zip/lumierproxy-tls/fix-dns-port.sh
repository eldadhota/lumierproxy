#!/bin/bash
# fix-dns-port.sh - Fix DNS port 53 conflict

echo "========================================="
echo "DNS Port 53 Conflict Fix"
echo "========================================="
echo ""

# Check what's using port 53
echo "Checking what's using port 53..."
sudo lsof -i :53 || sudo netstat -tulpn | grep :53

echo ""
echo "Common causes:"
echo "  - systemd-resolved (Ubuntu/Debian)"
echo "  - dnsmasq"
echo "  - bind9"
echo ""

read -p "Do you want to disable systemd-resolved? (yes/NO): " confirm

if [ "$confirm" = "yes" ]; then
    echo ""
    echo "Disabling systemd-resolved..."
    sudo systemctl stop systemd-resolved
    sudo systemctl disable systemd-resolved
    
    # Remove symlink and create real resolv.conf
    sudo rm /etc/resolv.conf
    echo "nameserver 8.8.8.8" | sudo tee /etc/resolv.conf
    echo "nameserver 1.1.1.1" | sudo tee -a /etc/resolv.conf
    
    echo "✓ systemd-resolved disabled"
    echo "✓ Created /etc/resolv.conf with Google DNS"
    echo ""
    echo "Now you can run: sudo ./lumierproxy"
    echo ""
else
    echo ""
    echo "Alternative: Lumier Proxy is already configured to use port 5353"
    echo ""
    echo "To use DNS leak prevention with port 5353:"
    echo "  1. Configure devices to use server IP as DNS"
    echo "  2. Add port forwarding (optional):"
    echo "     sudo iptables -t nat -A PREROUTING -p udp --dport 53 -j REDIRECT --to-port 5353"
    echo ""
    echo "Or simply run without DNS leak prevention (proxy still works):"
    echo "  sudo ./lumierproxy"
    echo ""
fi
