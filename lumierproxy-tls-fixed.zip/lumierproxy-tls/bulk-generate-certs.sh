#!/bin/bash
# bulk-generate-certs.sh - Generate certificates for multiple devices from CSV

set -e

CSV_FILE=${1:-devices.csv}

if [ ! -f "$CSV_FILE" ]; then
    echo "Usage: ./bulk-generate-certs.sh [devices.csv]"
    echo ""
    echo "CSV format: device_id,device_name,password(optional)"
    echo ""
    echo "Example devices.csv:"
    echo "device001,Johns Phone"
    echo "device002,Marys Tablet,custom_pass"
    echo "device003,Warehouse Phone 1"
    echo ""
    exit 1
fi

echo "========================================="
echo "Bulk Certificate Generation"
echo "========================================="
echo ""
echo "Reading from: $CSV_FILE"
echo ""

# Count total devices
total=$(grep -v "^#" "$CSV_FILE" | grep -v "^$" | wc -l)
current=0

echo "Found $total devices to process"
echo ""
read -p "Continue? (yes/NO): " confirm
if [ "$confirm" != "yes" ]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo "Generating certificates..."
echo ""

# Process each line
while IFS=',' read -r device_id device_name password || [ -n "$device_id" ]; do
    # Skip comments and empty lines
    if [[ "$device_id" =~ ^#.*$ ]] || [ -z "$device_id" ]; then
        continue
    fi
    
    current=$((current + 1))
    
    echo "[$current/$total] Processing: $device_name ($device_id)"
    
    if [ -n "$password" ]; then
        ./generate-device-cert.sh "$device_id" "$device_name" "$password" > /dev/null 2>&1
    else
        ./generate-device-cert.sh "$device_id" "$device_name" > /dev/null 2>&1
    fi
    
    if [ $? -eq 0 ]; then
        echo "  ✓ Certificate generated: ${device_id}.p12"
    else
        echo "  ❌ Failed to generate certificate"
    fi
    
done < "$CSV_FILE"

echo ""
echo "========================================="
echo "✓ Bulk Generation Complete!"
echo "========================================="
echo ""
echo "Generated $current certificates"
echo ""
echo "All .p12 files are in:"
echo "  certs/ (with backup .pem files)"
echo "  certs/downloads/ (for distribution)"
echo ""
echo "Next steps:"
echo "  1. Distribute .p12 files to respective devices"
echo "  2. Start server: sudo ./lumierproxy"
echo "  3. Configure devices with proxy: [server]:1443"
echo ""
