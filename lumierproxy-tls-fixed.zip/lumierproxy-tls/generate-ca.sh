#!/bin/bash
# generate-ca.sh - Generate Certificate Authority

set -e

echo "========================================="
echo "Lumier Proxy - CA Generation"
echo "========================================="
echo ""

# Create certs directory if it doesn't exist
mkdir -p certs
cd certs

# Check if CA already exists
if [ -f "ca-key.pem" ] || [ -f "ca-cert.pem" ]; then
    echo "⚠️  WARNING: CA certificate already exists!"
    echo ""
    read -p "Overwrite existing CA? This will invalidate ALL existing device certificates! (yes/NO): " confirm
    if [ "$confirm" != "yes" ]; then
        echo "Aborted."
        exit 1
    fi
    echo ""
fi

echo "Generating Certificate Authority..."
echo ""

# Generate CA private key (4096-bit, encrypted)
echo "Enter a strong password for the CA private key:"
echo "(You'll need this password when signing device certificates)"
openssl genrsa -aes256 -out ca-key.pem 4096

echo ""
echo "Enter certificate details for the CA:"
echo ""

# Generate CA certificate (valid 10 years)
openssl req -new -x509 -days 3650 -key ca-key.pem -sha256 -out ca-cert.pem

echo ""
echo "========================================="
echo "✓ Certificate Authority Created!"
echo "========================================="
echo ""
echo "Files created:"
echo "  ca-key.pem  - CA private key (KEEP SECRET! BACKUP SECURELY!)"
echo "  ca-cert.pem - CA public certificate"
echo ""
echo "⚠️  IMPORTANT:"
echo "  1. Backup ca-key.pem to a secure, offline location"
echo "  2. Never share ca-key.pem with anyone"
echo "  3. If ca-key.pem is compromised, all certificates must be regenerated"
echo ""
echo "Next steps:"
echo "  1. ./generate-server-cert.sh"
echo "  2. ./generate-device-cert.sh device001 'Device Name'"
echo ""
