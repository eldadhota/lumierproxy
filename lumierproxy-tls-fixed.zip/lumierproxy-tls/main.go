package main

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/miekg/dns"
	_ "github.com/mattn/go-sqlite3"
	"golang.org/x/net/proxy"
)

const (
	SOCKS5_VERSION = 0x05
	AUTH_NONE      = 0x00
	CMD_CONNECT    = 0x01
	ATYP_IPV4      = 0x01
	ATYP_DOMAIN    = 0x03
	ATYP_IPV6      = 0x04
	REP_SUCCESS    = 0x00
)

type Device struct {
	DeviceID        string    `json:"device_id"`
	DeviceName      string    `json:"device_name"`
	CertFingerprint string    `json:"cert_fingerprint"`
	AssignedProxy   string    `json:"assigned_proxy"`
	CurrentIP       string    `json:"current_ip"`
	FirstSeen       time.Time `json:"first_seen"`
	LastSeen        time.Time `json:"last_seen"`
	ConnectionCount int64     `json:"connection_count"`
}

type ProxyStats struct {
	BytesIn  int64 `json:"bytes_in"`
	BytesOut int64 `json:"bytes_out"`
	Requests int64 `json:"requests"`
}

type LumierProxy struct {
	db               *sql.DB
	proxies          []string
	proxyIndex       map[string]int // device_id -> proxy index
	devices          map[string]*Device
	devicesByCert    map[string]*Device // cert fingerprint -> device
	devicesMutex     sync.RWMutex
	stats            map[string]*ProxyStats
	statsMutex       sync.RWMutex
	dnsCache         map[string]*dnsCacheEntry
	dnsCacheMutex    sync.RWMutex
	tlsConfig        *tls.Config
	caCertPool       *x509.CertPool
	dnsPort          int
}

type dnsCacheEntry struct {
	IP        net.IP
	ExpiresAt time.Time
}

func main() {
	log.Println("Starting Lumier Proxy v4.0 - TLS Certificate Edition")

	// Initialize database
	db, err := sql.Open("sqlite3", "./device_bindings.db")
	if err != nil {
		log.Fatal("Failed to open database:", err)
	}
	defer db.Close()

	// Check if DNS port 53 is available
	dnsPort := 53
	ln, err := net.Listen("tcp", ":53")
	if err != nil {
		log.Println("⚠️  Port 53 already in use, will use port 5353 for DNS")
		dnsPort = 5353
	} else {
		ln.Close()
	}

	lp := &LumierProxy{
		db:            db,
		devices:       make(map[string]*Device),
		devicesByCert: make(map[string]*Device),
		proxyIndex:    make(map[string]int),
		stats:         make(map[string]*ProxyStats),
		dnsCache:      make(map[string]*dnsCacheEntry),
		dnsPort:       dnsPort,
	}

	// Initialize database schema
	if err := lp.initDatabase(); err != nil {
		log.Fatal("Failed to initialize database:", err)
	}

	// Load CA certificate for client verification
	if err := lp.loadCACertificate("certs/ca-cert.pem"); err != nil {
		log.Fatal("Failed to load CA certificate:", err)
	}

	// Load server certificate for TLS
	if err := lp.loadServerCertificate("certs/server-cert.pem", "certs/server-key.pem"); err != nil {
		log.Fatal("Failed to load server certificate:", err)
	}

	// Load proxies from file
	if err := lp.loadProxies("proxies.txt"); err != nil {
		log.Fatal("Failed to load proxies:", err)
	}

	// Load existing devices from database
	if err := lp.loadDevices(); err != nil {
		log.Fatal("Failed to load devices:", err)
	}

	log.Printf("Loaded %d proxies", len(lp.proxies))
	log.Printf("Loaded %d existing devices", len(lp.devices))

	// Start DNS server on alternate port (53 may be in use by systemd-resolved)
	go lp.startDNSServer(5353)

	// Start web dashboard
	go lp.startWebDashboard(8080)

	// Start TLS proxy server (with client cert authentication)
	log.Println("Starting TLS proxy server on :1443 (requires client certificate)")
	lp.startTLSProxyServer(1443)
}

func (lp *LumierProxy) initDatabase() error {
	schema := `
	CREATE TABLE IF NOT EXISTS devices (
		device_id TEXT PRIMARY KEY,
		device_name TEXT NOT NULL,
		cert_fingerprint TEXT UNIQUE NOT NULL,
		assigned_proxy TEXT NOT NULL,
		current_ip TEXT,
		first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		connection_count INTEGER DEFAULT 0
	);
	
	CREATE INDEX IF NOT EXISTS idx_cert_fingerprint ON devices(cert_fingerprint);
	CREATE INDEX IF NOT EXISTS idx_assigned_proxy ON devices(assigned_proxy);
	
	CREATE TABLE IF NOT EXISTS proxy_stats (
		proxy_url TEXT PRIMARY KEY,
		bytes_in INTEGER DEFAULT 0,
		bytes_out INTEGER DEFAULT 0,
		requests INTEGER DEFAULT 0,
		last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
	);
	
	CREATE TABLE IF NOT EXISTS connection_log (
		device_id TEXT,
		ip_address TEXT,
		connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		FOREIGN KEY(device_id) REFERENCES devices(device_id)
	);
	
	CREATE INDEX IF NOT EXISTS idx_connection_log ON connection_log(device_id, connected_at);
	`
	_, err := lp.db.Exec(schema)
	return err
}

func (lp *LumierProxy) loadCACertificate(path string) error {
	caCert, err := ioutil.ReadFile(path)
	if err != nil {
		return fmt.Errorf("failed to read CA certificate: %v", err)
	}

	lp.caCertPool = x509.NewCertPool()
	if !lp.caCertPool.AppendCertsFromPEM(caCert) {
		return fmt.Errorf("failed to parse CA certificate")
	}

	log.Println("✓ Loaded CA certificate for client verification")
	return nil
}

func (lp *LumierProxy) loadServerCertificate(certPath, keyPath string) error {
	cert, err := tls.LoadX509KeyPair(certPath, keyPath)
	if err != nil {
		return fmt.Errorf("failed to load server certificate: %v", err)
	}

	lp.tlsConfig = &tls.Config{
		Certificates: []tls.Certificate{cert},
		ClientAuth:   tls.RequireAndVerifyClientCert,
		ClientCAs:    lp.caCertPool,
		MinVersion:   tls.VersionTLS12,
	}

	log.Println("✓ Loaded server certificate for TLS")
	return nil
}

func (lp *LumierProxy) loadProxies(filename string) error {
	file, err := os.Open(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" && !strings.HasPrefix(line, "#") {
			lp.proxies = append(lp.proxies, line)
		}
	}

	if len(lp.proxies) == 0 {
		return fmt.Errorf("no proxies loaded from %s", filename)
	}

	return scanner.Err()
}

func (lp *LumierProxy) loadDevices() error {
	rows, err := lp.db.Query(`
		SELECT device_id, device_name, cert_fingerprint, assigned_proxy, 
		       current_ip, first_seen, last_seen, connection_count
		FROM devices
	`)
	if err != nil {
		return err
	}
	defer rows.Close()

	for rows.Next() {
		var device Device
		var currentIP sql.NullString

		err := rows.Scan(
			&device.DeviceID,
			&device.DeviceName,
			&device.CertFingerprint,
			&device.AssignedProxy,
			&currentIP,
			&device.FirstSeen,
			&device.LastSeen,
			&device.ConnectionCount,
		)
		if err != nil {
			log.Printf("Error loading device: %v", err)
			continue
		}

		if currentIP.Valid {
			device.CurrentIP = currentIP.String
		}

		// Find proxy index
		for i, p := range lp.proxies {
			if p == device.AssignedProxy {
				lp.proxyIndex[device.DeviceID] = i
				break
			}
		}

		lp.devices[device.DeviceID] = &device
		lp.devicesByCert[device.CertFingerprint] = &device
	}

	return rows.Err()
}

func (lp *LumierProxy) getCertFingerprint(cert *x509.Certificate) string {
	// Use certificate's Subject Common Name (CN) as device ID
	// The CN was set when we generated the certificate (e.g., "device001")
	return cert.Subject.CommonName
}

func (lp *LumierProxy) getOrCreateDevice(deviceID, certFingerprint, clientIP string) (*Device, error) {
	lp.devicesMutex.Lock()
	defer lp.devicesMutex.Unlock()

	// Check if device exists by device ID
	if device, exists := lp.devices[deviceID]; exists {
		// Update current IP and last seen
		device.CurrentIP = clientIP
		device.LastSeen = time.Now()
		device.ConnectionCount++

		// Update database
		lp.db.Exec(`
			UPDATE devices 
			SET last_seen = ?, current_ip = ?, connection_count = ?
			WHERE device_id = ?
		`, device.LastSeen, device.CurrentIP, device.ConnectionCount, deviceID)

		// Log connection
		lp.db.Exec(`
			INSERT INTO connection_log (device_id, ip_address, connected_at)
			VALUES (?, ?, ?)
		`, deviceID, clientIP, time.Now())

		return device, nil
	}

	// Create new device
	assignedProxy := lp.assignProxyToDevice(deviceID)
	device := &Device{
		DeviceID:        deviceID,
		DeviceName:      deviceID, // Default name, can be changed in dashboard
		CertFingerprint: certFingerprint,
		AssignedProxy:   assignedProxy,
		CurrentIP:       clientIP,
		FirstSeen:       time.Now(),
		LastSeen:        time.Now(),
		ConnectionCount: 1,
	}

	// Save to database
	_, err := lp.db.Exec(`
		INSERT INTO devices 
		(device_id, device_name, cert_fingerprint, assigned_proxy, current_ip, 
		 first_seen, last_seen, connection_count)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)
	`, device.DeviceID, device.DeviceName, device.CertFingerprint, device.AssignedProxy,
		device.CurrentIP, device.FirstSeen, device.LastSeen, device.ConnectionCount)

	if err != nil {
		return nil, err
	}

	// Log first connection
	lp.db.Exec(`
		INSERT INTO connection_log (device_id, ip_address, connected_at)
		VALUES (?, ?, ?)
	`, deviceID, clientIP, time.Now())

	lp.devices[deviceID] = device
	lp.devicesByCert[certFingerprint] = device

	log.Printf("✓ New device registered: %s (IP: %s) -> %s", deviceID, clientIP, assignedProxy)

	return device, nil
}

func (lp *LumierProxy) assignProxyToDevice(deviceID string) string {
	// Round-robin assignment
	index := len(lp.devices) % len(lp.proxies)
	lp.proxyIndex[deviceID] = index
	return lp.proxies[index]
}

func (lp *LumierProxy) getDeviceByIP(clientIP string) *Device {
	lp.devicesMutex.RLock()
	defer lp.devicesMutex.RUnlock()

	for _, device := range lp.devices {
		if device.CurrentIP == clientIP {
			return device
		}
	}
	return nil
}

// TLS Proxy Server with Client Certificate Authentication
func (lp *LumierProxy) startTLSProxyServer(port int) {
	listener, err := tls.Listen("tcp", fmt.Sprintf(":%d", port), lp.tlsConfig)
	if err != nil {
		log.Fatal("Failed to start TLS proxy server:", err)
	}
	defer listener.Close()

	log.Printf("TLS proxy server listening on port %d (Client cert required)", port)

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Error accepting connection: %v", err)
			continue
		}

		go lp.handleTLSConnection(conn)
	}
}

func (lp *LumierProxy) handleTLSConnection(conn net.Conn) {
	defer conn.Close()

	// Get client certificate from TLS connection
	tlsConn, ok := conn.(*tls.Conn)
	if !ok {
		log.Println("Not a TLS connection")
		return
	}

	// Force handshake to get client certificate
	if err := tlsConn.Handshake(); err != nil {
		log.Printf("TLS handshake failed: %v", err)
		return
	}

	state := tlsConn.ConnectionState()
	if len(state.PeerCertificates) == 0 {
		log.Println("No client certificate provided")
		return
	}

	clientCert := state.PeerCertificates[0]
	deviceID := lp.getCertFingerprint(clientCert)
	clientIP := strings.Split(conn.RemoteAddr().String(), ":")[0]

	// Get or create device
	device, err := lp.getOrCreateDevice(deviceID, clientCert.SerialNumber.String(), clientIP)
	if err != nil {
		log.Printf("Failed to get/create device %s: %v", deviceID, err)
		return
	}

	log.Printf("Device %s (%s) connected from %s", device.DeviceName, deviceID, clientIP)

	// Now handle SOCKS5 protocol over this TLS connection
	lp.handleSOCKS5OverTLS(tlsConn, device)
}

func (lp *LumierProxy) handleSOCKS5OverTLS(conn net.Conn, device *Device) {
	// SOCKS5 greeting
	buf := make([]byte, 257)
	n, err := conn.Read(buf)
	if err != nil || n < 2 || buf[0] != SOCKS5_VERSION {
		return
	}

	// Accept NO AUTHENTICATION (we already authenticated via TLS cert)
	conn.Write([]byte{SOCKS5_VERSION, AUTH_NONE})

	// Read connection request
	n, err = conn.Read(buf)
	if err != nil || n < 4 || buf[0] != SOCKS5_VERSION || buf[1] != CMD_CONNECT {
		return
	}

	// Parse target address
	var targetHost string
	var targetPort uint16

	addrType := buf[3]
	switch addrType {
	case ATYP_IPV4:
		if n < 10 {
			return
		}
		targetHost = fmt.Sprintf("%d.%d.%d.%d", buf[4], buf[5], buf[6], buf[7])
		targetPort = uint16(buf[8])<<8 | uint16(buf[9])

	case ATYP_DOMAIN:
		if n < 5 {
			return
		}
		domainLen := int(buf[4])
		if n < 5+domainLen+2 {
			return
		}
		domain := string(buf[5 : 5+domainLen])

		// Resolve through assigned proxy's DNS
		resolvedIP, err := lp.resolveThroughProxy(domain, device.AssignedProxy)
		if err != nil {
			log.Printf("DNS resolution failed for %s: %v", domain, err)
			conn.Write([]byte{SOCKS5_VERSION, 0x04, 0x00, ATYP_IPV4, 0, 0, 0, 0, 0, 0})
			return
		}

		targetHost = resolvedIP.String()
		targetPort = uint16(buf[5+domainLen])<<8 | uint16(buf[5+domainLen+1])

	case ATYP_IPV6:
		if n < 22 {
			return
		}
		targetHost = net.IP(buf[4:20]).String()
		targetPort = uint16(buf[20])<<8 | uint16(buf[21])

	default:
		conn.Write([]byte{SOCKS5_VERSION, 0x08, 0x00, ATYP_IPV4, 0, 0, 0, 0, 0, 0})
		return
	}

	target := fmt.Sprintf("%s:%d", targetHost, targetPort)

	// Connect through assigned proxy
	remoteConn, err := lp.connectThroughProxy(target, device.AssignedProxy)
	if err != nil {
		log.Printf("Failed to connect to %s through proxy for %s: %v", target, device.DeviceName, err)
		conn.Write([]byte{SOCKS5_VERSION, 0x05, 0x00, ATYP_IPV4, 0, 0, 0, 0, 0, 0})
		return
	}
	defer remoteConn.Close()

	// Send success response
	conn.Write([]byte{SOCKS5_VERSION, REP_SUCCESS, 0x00, ATYP_IPV4, 0, 0, 0, 0, 0, 0})

	// Relay traffic
	lp.relayTraffic(conn, remoteConn, device)
}

func (lp *LumierProxy) connectThroughProxy(target, proxyURL string) (net.Conn, error) {
	parsedURL, err := url.Parse(proxyURL)
	if err != nil {
		return nil, err
	}

	dialer, err := proxy.FromURL(parsedURL, proxy.Direct)
	if err != nil {
		return nil, err
	}

	return dialer.Dial("tcp", target)
}

func (lp *LumierProxy) relayTraffic(client, remote net.Conn, device *Device) {
	var wg sync.WaitGroup
	wg.Add(2)

	// Client -> Remote
	go func() {
		defer wg.Done()
		bytes, _ := io.Copy(remote, client)
		lp.updateStats(device.AssignedProxy, bytes, 0, 1)
	}()

	// Remote -> Client
	go func() {
		defer wg.Done()
		bytes, _ := io.Copy(client, remote)
		lp.updateStats(device.AssignedProxy, 0, bytes, 0)
	}()

	wg.Wait()
}

func (lp *LumierProxy) updateStats(proxyURL string, bytesIn, bytesOut int64, requests int64) {
	lp.statsMutex.Lock()
	defer lp.statsMutex.Unlock()

	if _, exists := lp.stats[proxyURL]; !exists {
		lp.stats[proxyURL] = &ProxyStats{}
	}

	lp.stats[proxyURL].BytesIn += bytesIn
	lp.stats[proxyURL].BytesOut += bytesOut
	lp.stats[proxyURL].Requests += requests

	go func() {
		lp.db.Exec(`
			INSERT INTO proxy_stats (proxy_url, bytes_in, bytes_out, requests, last_updated)
			VALUES (?, ?, ?, ?, ?)
			ON CONFLICT(proxy_url) DO UPDATE SET
				bytes_in = bytes_in + excluded.bytes_in,
				bytes_out = bytes_out + excluded.bytes_out,
				requests = requests + excluded.requests,
				last_updated = excluded.last_updated
		`, proxyURL, bytesIn, bytesOut, requests, time.Now())
	}()
}

// DNS Server
func (lp *LumierProxy) startDNSServer(port int) {
	srv := &dns.Server{
		Addr: fmt.Sprintf(":%d", port),
		Net:  "udp",
	}

	dns.HandleFunc(".", lp.handleDNSQuery)

	log.Printf("Starting DNS server on port %d", port)
	log.Printf("Note: Configure devices to use server IP as DNS server")
	if err := srv.ListenAndServe(); err != nil {
		log.Printf("DNS server error: %v", err)
		log.Println("DNS server failed to start. Continuing without DNS leak prevention.")
	}
}

func (lp *LumierProxy) handleDNSQuery(w dns.ResponseWriter, r *dns.Msg) {
	msg := new(dns.Msg)
	msg.SetReply(r)
	msg.Authoritative = true

	clientIP := strings.Split(w.RemoteAddr().String(), ":")[0]
	device := lp.getDeviceByIP(clientIP)

	if device == nil {
		dns.HandleFailed(w, r)
		return
	}

	for _, q := range r.Question {
		if q.Qtype == dns.TypeA {
			domain := strings.TrimSuffix(q.Name, ".")

			// Check cache
			if cachedIP := lp.getDNSCache(domain); cachedIP != nil {
				msg.Answer = append(msg.Answer, &dns.A{
					Hdr: dns.RR_Header{
						Name:   q.Name,
						Rrtype: dns.TypeA,
						Class:  dns.ClassINET,
						Ttl:    300,
					},
					A: cachedIP,
				})
				continue
			}

			// Resolve through assigned proxy
			ip, err := lp.resolveThroughProxy(domain, device.AssignedProxy)
			if err != nil {
				log.Printf("DNS failed for %s: %v", domain, err)
				continue
			}

			lp.setDNSCache(domain, ip)

			msg.Answer = append(msg.Answer, &dns.A{
				Hdr: dns.RR_Header{
					Name:   q.Name,
					Rrtype: dns.TypeA,
					Class:  dns.ClassINET,
					Ttl:    300,
				},
				A: ip,
			})
		}
	}

	w.WriteMsg(msg)
}

func (lp *LumierProxy) resolveThroughProxy(domain, proxyURL string) (net.IP, error) {
	parsedURL, err := url.Parse(proxyURL)
	if err != nil {
		return nil, err
	}

	dialer, err := proxy.FromURL(parsedURL, proxy.Direct)
	if err != nil {
		return nil, err
	}

	conn, err := dialer.Dial("tcp", "8.8.8.8:53")
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	m := new(dns.Msg)
	m.SetQuestion(dns.Fqdn(domain), dns.TypeA)

	dnsConn := &dns.Conn{Conn: conn}
	err = dnsConn.WriteMsg(m)
	if err != nil {
		return nil, err
	}

	response, err := dnsConn.ReadMsg()
	if err != nil {
		return nil, err
	}

	for _, answer := range response.Answer {
		if a, ok := answer.(*dns.A); ok {
			return a.A, nil
		}
	}

	return nil, fmt.Errorf("no A record for %s", domain)
}

func (lp *LumierProxy) getDNSCache(domain string) net.IP {
	lp.dnsCacheMutex.RLock()
	defer lp.dnsCacheMutex.RUnlock()

	if entry, exists := lp.dnsCache[domain]; exists {
		if time.Now().Before(entry.ExpiresAt) {
			return entry.IP
		}
	}
	return nil
}

func (lp *LumierProxy) setDNSCache(domain string, ip net.IP) {
	lp.dnsCacheMutex.Lock()
	defer lp.dnsCacheMutex.Unlock()

	lp.dnsCache[domain] = &dnsCacheEntry{
		IP:        ip,
		ExpiresAt: time.Now().Add(5 * time.Minute),
	}
}

// Web Dashboard
func (lp *LumierProxy) startWebDashboard(port int) {
	http.HandleFunc("/", lp.handleDashboard)
	http.HandleFunc("/api/devices", lp.handleDevicesAPI)
	http.HandleFunc("/api/stats", lp.handleStatsAPI)
	http.HandleFunc("/api/device/reassign", lp.handleReassignDevice)
	http.HandleFunc("/api/device/rename", lp.handleRenameDevice)
	http.Handle("/certs/", http.StripPrefix("/certs/", http.FileServer(http.Dir("./certs/downloads"))))

	log.Printf("Starting web dashboard on http://localhost:%d", port)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", port), nil))
}

func (lp *LumierProxy) handleDashboard(w http.ResponseWriter, r *http.Request) {
	html := `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lumier Proxy - TLS Certificate Edition</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
            line-height: 1.6;
        }
        h1 { color: #333; margin-bottom: 20px; }
        h2 { color: #444; margin-bottom: 15px; font-size: 1.5em; }
        .container { 
            background: white;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        table { 
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td { 
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th { 
            background: #4CAF50;
            color: white;
            font-weight: 600;
        }
        tr:hover { background: #f9f9f9; }
        .stats { 
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }
        .stat-box { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .stat-value { 
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .stat-label { 
            font-size: 0.9em;
            opacity: 0.9;
        }
        button { 
            background: #4CAF50;
            color: white;
            border: none;
            padding: 8px 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-right: 5px;
            font-size: 0.9em;
            transition: background 0.3s;
        }
        button:hover { background: #45a049; }
        .info-banner { 
            background: #e8f5e9;
            padding: 15px;
            border-left: 4px solid #4CAF50;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .info-banner strong { color: #2e7d32; }
        .loading { text-align: center; padding: 20px; color: #666; }
        .error { 
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-left: 4px solid #c62828;
            border-radius: 4px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <h1>🔒 Lumier Proxy - TLS Certificate Edition</h1>
    
    <div class="info-banner">
        <strong>✓ Certificate Authentication Active</strong><br>
        Devices identified by TLS client certificates. No IP/MAC dependency.<br>
        Survives network changes, DHCP rotation, and roaming.
    </div>
    
    <div class="container">
        <h2>System Statistics</h2>
        <div class="stats" id="stats">
            <div class="loading">Loading statistics...</div>
        </div>
    </div>
    
    <div class="container">
        <h2>Connected Devices</h2>
        <div id="devices-container">
            <div class="loading">Loading devices...</div>
        </div>
    </div>

    <script>
        let updateInterval;

        function showError(containerId, message) {
            const container = document.getElementById(containerId);
            container.innerHTML = '<div class="error">Error: ' + message + '</div>';
        }

        function loadStats() {
            fetch('/api/stats')
                .then(response => {
                    if (!response.ok) throw new Error('Failed to load stats');
                    return response.json();
                })
                .then(data => {
                    const statsHtml = Object.entries(data).map(([key, val]) => 
                        '<div class="stat-box">' +
                        '<div class="stat-value">' + val + '</div>' +
                        '<div class="stat-label">' + key + '</div>' +
                        '</div>'
                    ).join('');
                    document.getElementById('stats').innerHTML = statsHtml;
                })
                .catch(error => {
                    console.error('Stats error:', error);
                    showError('stats', 'Could not load statistics');
                });
        }

        function loadDevices() {
            fetch('/api/devices')
                .then(response => {
                    if (!response.ok) throw new Error('Failed to load devices');
                    return response.json();
                })
                .then(devices => {
                    if (!devices || devices.length === 0) {
                        document.getElementById('devices-container').innerHTML = 
                            '<p style="padding: 20px; text-align: center; color: #666;">No devices connected yet</p>';
                        return;
                    }

                    const tableHtml = '<table id="devices">' +
                        '<thead><tr>' +
                        '<th>Device Name</th>' +
                        '<th>Device ID</th>' +
                        '<th>Current IP</th>' +
                        '<th>Assigned Proxy</th>' +
                        '<th>Connections</th>' +
                        '<th>Last Seen</th>' +
                        '<th>Actions</th>' +
                        '</tr></thead><tbody>' +
                        devices.map(d => 
                            '<tr>' +
                            '<td>' + escapeHtml(d.device_name || 'Unknown') + '</td>' +
                            '<td>' + escapeHtml(d.device_id || 'N/A') + '</td>' +
                            '<td>' + escapeHtml(d.current_ip || 'N/A') + '</td>' +
                            '<td>' + escapeHtml((d.assigned_proxy || '').substring(0, 40)) + '...</td>' +
                            '<td>' + (d.connection_count || 0) + '</td>' +
                            '<td>' + formatDate(d.last_seen) + '</td>' +
                            '<td>' +
                            '<button onclick="rename(\'' + escapeHtml(d.device_id) + '\', \'' + 
                                escapeHtml(d.device_name) + '\')">Rename</button>' +
                            '<button onclick="reassign(\'' + escapeHtml(d.device_id) + '\')">Reassign</button>' +
                            '</td>' +
                            '</tr>'
                        ).join('') +
                        '</tbody></table>';
                    
                    document.getElementById('devices-container').innerHTML = tableHtml;
                })
                .catch(error => {
                    console.error('Devices error:', error);
                    showError('devices-container', 'Could not load devices');
                });
        }

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function formatDate(dateString) {
            if (!dateString) return 'Never';
            try {
                return new Date(dateString).toLocaleString();
            } catch (e) {
                return 'Invalid date';
            }
        }

        function reassign(deviceID) {
            if (!deviceID) return;
            if (!confirm('Reassign proxy for ' + deviceID + '?')) return;
            
            fetch('/api/device/reassign?id=' + encodeURIComponent(deviceID), {method: 'POST'})
                .then(response => {
                    if (!response.ok) throw new Error('Reassign failed');
                    loadDevices();
                })
                .catch(error => {
                    alert('Error reassigning device: ' + error.message);
                });
        }

        function rename(deviceID, currentName) {
            if (!deviceID) return;
            const newName = prompt('Enter new name:', currentName);
            if (!newName || newName === currentName) return;
            
            fetch('/api/device/rename?id=' + encodeURIComponent(deviceID) + 
                  '&name=' + encodeURIComponent(newName), {method: 'POST'})
                .then(response => {
                    if (!response.ok) throw new Error('Rename failed');
                    loadDevices();
                })
                .catch(error => {
                    alert('Error renaming device: ' + error.message);
                });
        }

        function loadData() {
            loadStats();
            loadDevices();
        }

        // Initial load
        loadData();

        // Auto-refresh every 5 seconds
        updateInterval = setInterval(loadData, 5000);

        // Stop refresh when page is hidden
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                clearInterval(updateInterval);
            } else {
                loadData();
                updateInterval = setInterval(loadData, 5000);
            }
        });
    </script>
</body>
</html>`
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write([]byte(html))
}

func (lp *LumierProxy) handleDevicesAPI(w http.ResponseWriter, r *http.Request) {
	lp.devicesMutex.RLock()
	defer lp.devicesMutex.RUnlock()

	devices := make([]*Device, 0, len(lp.devices))
	for _, device := range lp.devices {
		devices = append(devices, device)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(devices)
}

func (lp *LumierProxy) handleStatsAPI(w http.ResponseWriter, r *http.Request) {
	lp.devicesMutex.RLock()
	totalDevices := len(lp.devices)
	lp.devicesMutex.RUnlock()

	lp.statsMutex.RLock()
	var totalBytes, totalRequests int64
	for _, stat := range lp.stats {
		totalBytes += stat.BytesIn + stat.BytesOut
		totalRequests += stat.Requests
	}
	lp.statsMutex.RUnlock()

	stats := map[string]interface{}{
		"Total Devices":  totalDevices,
		"Total Proxies":  len(lp.proxies),
		"Total Traffic":  fmt.Sprintf("%.2f GB", float64(totalBytes)/1024/1024/1024),
		"Total Requests": totalRequests,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(stats)
}

func (lp *LumierProxy) handleReassignDevice(w http.ResponseWriter, r *http.Request) {
	deviceID := r.URL.Query().Get("id")
	if deviceID == "" {
		http.Error(w, "id required", http.StatusBadRequest)
		return
	}

	lp.devicesMutex.Lock()
	defer lp.devicesMutex.Unlock()

	device, exists := lp.devices[deviceID]
	if !exists {
		http.Error(w, "device not found", http.StatusNotFound)
		return
	}

	currentIndex := lp.proxyIndex[deviceID]
	newIndex := (currentIndex + 1) % len(lp.proxies)
	newProxy := lp.proxies[newIndex]

	device.AssignedProxy = newProxy
	lp.proxyIndex[deviceID] = newIndex

	lp.db.Exec("UPDATE devices SET assigned_proxy = ? WHERE device_id = ?", newProxy, deviceID)

	log.Printf("Reassigned %s to %s", device.DeviceName, newProxy)
	w.WriteHeader(http.StatusOK)
}

func (lp *LumierProxy) handleRenameDevice(w http.ResponseWriter, r *http.Request) {
	deviceID := r.URL.Query().Get("id")
	newName := r.URL.Query().Get("name")

	if deviceID == "" || newName == "" {
		http.Error(w, "id and name required", http.StatusBadRequest)
		return
	}

	lp.devicesMutex.Lock()
	defer lp.devicesMutex.Unlock()

	device, exists := lp.devices[deviceID]
	if !exists {
		http.Error(w, "device not found", http.StatusNotFound)
		return
	}

	device.DeviceName = newName
	lp.db.Exec("UPDATE devices SET device_name = ? WHERE device_id = ?", newName, deviceID)

	log.Printf("Renamed %s to %s", deviceID, newName)
	w.WriteHeader(http.StatusOK)
}
