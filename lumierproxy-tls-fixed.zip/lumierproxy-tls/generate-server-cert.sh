#!/bin/bash
# generate-server-cert.sh - Generate server certificate for TLS

set -e

echo "========================================="
echo "Lumier Proxy - Server Certificate"
echo "========================================="
echo ""

cd certs

# Check if CA exists
if [ ! -f "ca-key.pem" ] || [ ! -f "ca-cert.pem" ]; then
    echo "❌ Error: CA certificate not found!"
    echo "Run ./generate-ca.sh first"
    exit 1
fi

# Check if server cert already exists
if [ -f "server-key.pem" ] || [ -f "server-cert.pem" ]; then
    echo "⚠️  Server certificate already exists"
    read -p "Regenerate? (yes/NO): " confirm
    if [ "$confirm" != "yes" ]; then
        echo "Aborted."
        exit 1
    fi
fi

echo "Generating server certificate..."

# Generate server private key
openssl genrsa -out server-key.pem 2048

# Generate certificate signing request
openssl req -new -key server-key.pem -out server-csr.pem \
    -subj "/C=US/ST=California/L=San Francisco/O=Lumier Proxy/CN=lumierproxy.local"

# Sign with CA (valid 2 years)
openssl x509 -req -in server-csr.pem -CA ca-cert.pem -CAkey ca-key.pem \
    -CAcreateserial -out server-cert.pem -days 730 -sha256

# Clean up
rm server-csr.pem

# Set permissions
chmod 600 server-key.pem
chmod 644 server-cert.pem

echo ""
echo "✓ Server certificate generated!"
echo ""
echo "Files created:"
echo "  server-key.pem  - Server private key"
echo "  server-cert.pem - Server certificate"
echo ""
echo "These files should be in /opt/lumierproxy/certs/"
echo ""
echo "Next: Generate device certificates"
echo "  ./generate-device-cert.sh device001 'Johns Phone'"
echo ""
