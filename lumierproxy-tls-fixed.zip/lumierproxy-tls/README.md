# Lumier Proxy v4.0 - TLS Certificate Edition

**The ultimate solution for environments with:**
- DHCP pool rotation
- Multiple networks
- Short DHCP leases
- Device roaming
- No static IP capability

## How It Works

### Device Identification via TLS Client Certificates

```
Device connects → TLS handshake → Presents certificate
→ Server reads device ID from certificate
→ Assigns/retrieves proxy for that device
→ Routes all traffic through assigned proxy
```

**Key Advantage:** Device identified by cryptographic certificate, not by IP address or MAC address.

## Setup Overview

**Server side:**
1. Generate CA certificate (once)
2. Generate server certificate (once)
3. Generate device certificates (one per device)
4. Start server

**Device side:**
1. Install certificate (.p12 file)
2. Configure Wi-Fi proxy hostname:1443
3. Done!

## Quick Start

### Step 1: Generate Certificates

```bash
# Install OpenSSL (if not installed)
sudo apt-get install openssl

# Generate CA (once)
./generate-ca.sh

# Generate server certificate (once)
./generate-server-cert.sh

# Generate device certificates
./generate-device-cert.sh device001 "Johns Phone"
./generate-device-cert.sh device002 "Marys Tablet"
./generate-device-cert.sh device003 "Warehouse Phone"

# Or bulk generate from CSV
./bulk-generate-certs.sh devices.csv
```

### Step 2: Configure Server

```bash
# Add your Bright Data proxies
nano proxies.txt

# Add (one per line):
socks5://customer-USER-zone-residential:PASS@brd.superproxy.io:33335
socks5://customer-USER-zone-residential:PASS@brd.superproxy.io:33335
```

### Step 3: Start Server

```bash
# Build
go build -o lumierproxy main.go

# Start (requires sudo for DNS port 53)
sudo ./lumierproxy
```

### Step 4: Install Certificate on Device

**Transfer .p12 file to device:**
- Email attachment
- USB cable
- Cloud storage (Google Drive, Dropbox)
- Local download server (server hosts files on port 8080/certs/)

**Install on Android:**
```
1. Download device001.p12
2. Tap file to install
3. Enter password: lumier2024
4. Name: Johns Phone
5. Tap OK
```

### Step 5: Configure Device Proxy

```
Settings → Wi-Fi → [Network] → Modify network

Proxy: Manual
Hostname: 192.168.1.100 (your server IP)
Port: 1443              ← Important: 1443, not 1080!

Optional (recommended):
IP settings: Static
DNS 1: 192.168.1.100
```

### Step 6: Test

1. Open browser → google.com (should load)
2. Visit: https://whatismyipaddress.com (should show proxy IP)
3. Visit: https://dnsleaktest.com (should show proxy DNS)
4. Dashboard: http://192.168.1.100:8080 (should see device)

## Certificate Files Explained

### After running generate-ca.sh:
```
certs/
  ca-key.pem   ← CA private key (CRITICAL! Keep secret!)
  ca-cert.pem  ← CA public certificate
```

### After running generate-server-cert.sh:
```
certs/
  server-key.pem   ← Server private key
  server-cert.pem  ← Server certificate
```

### After running generate-device-cert.sh:
```
certs/
  device001-key.pem    ← Device private key (backup)
  device001-cert.pem   ← Device certificate (backup)
  device001.p12        ← Install THIS on device
  downloads/
    device001.p12      ← Copy for easy distribution
```

## Distribution Methods

### Method 1: Email (Easiest)

Email the .p12 file directly to device owner with instructions.

### Method 2: Download Server (Best for 10+devices)

Server automatically serves certificates:
```
http://192.168.1.100:8080/certs/device001.p12
http://192.168.1.100:8080/certs/device002.p12
```

Send users the download link.

### Method 3: QR Codes

Generate QR codes for each device:
```bash
sudo apt-get install qrencode

for p12 in certs/*.p12; do
    device=$(basename "$p12" .p12)
    qrencode -o "${device}-qr.png" \
        "http://192.168.1.100:8080/certs/$(basename $p12)"
done
```

Print/display QR, user scans to download.

### Method 4: MDM (Enterprise)

Use Mobile Device Management to push certificates:
- Google Workspace
- Microsoft Intune
- VMware Workspace ONE

## Advantages Over Other Methods

| Feature | TLS Certs | IP-Based | MAC-Based | Username/Password |
|---------|-----------|----------|-----------|-------------------|
| Survives DHCP rotation | ✅ | ❌ | ✅ | ✅ |
| Survives network switching | ✅ | ❌ | ✅ | ✅ |
| Works without static IPs | ✅ | ❌ | ✅ | ✅ |
| No Android auth fields needed | ✅ | ✅ | ✅ | ❌ |
| Cryptographically unique | ✅ | ❌ | ❌ | ⚠️ |
| Can't be duplicated | ✅ | ❌ | ❌ | ❌ |
| Revocable | ✅ | ❌ | ❌ | ✅ |
| Zero server config | ✅ | ❌ | ⚠️ | ✅ |

## Troubleshooting

### Issue: "Certificate not trusted"

**Cause:** CA not installed on device

**Fix:**
1. First install CA certificate (ca-cert.pem)
2. Then install device certificate

### Issue: Connection fails

**Check:**
```bash
# Verify certificates generated
ls -la certs/

# Check server logs
sudo journalctl -u lumierproxy -f

# Test TLS handshake
openssl s_client -connect 192.168.1.100:1443 -cert certs/device001-cert.pem -key certs/device001-key.pem
```

### Issue: Device not appearing in dashboard

**Check:**
1. Certificate installed? Settings → Security → Trusted credentials → User
2. Proxy configured correctly? (hostname:1443)
3. Server running? `ps aux | grep lumierproxy`
4. Firewall allowing port 1443? `sudo ufw status`

### Issue: DNS leaking

**Fix:**
1. Set device DNS to server IP
2. Disable Private DNS on Android
3. Check DNS server running: `sudo netstat -ulnp | grep :53`

## Security

### Certificate Security

**Critical files:**
- `ca-key.pem` - MOST IMPORTANT. Keep encrypted, offline backup
- `server-key.pem` - Keep on server only
- `device*-key.pem` - Embedded in .p12, password protected

**Best practices:**
1. Strong password for CA key
2. Unique password per device (or per batch)
3. Offline backup of CA key
4. Revoke lost/stolen certificates

### Revoking Certificates

If device is lost:

**Option 1: Delete from database**
```bash
sqlite3 device_bindings.db "DELETE FROM devices WHERE device_id = 'device001';"
```

**Option 2: Generate CRL (advanced)**
```bash
openssl ca -revoke certs/device001-cert.pem -keyfile certs/ca-key.pem -cert certs/ca-cert.pem
openssl ca -gencrl -out certs/crl.pem -keyfile certs/ca-key.pem -cert certs/ca-cert.pem
# Update server to check CRL
```

## Certificate Renewal

Certificates valid for 2 years. To renew:

```bash
# Regenerate expiring certificate
./generate-device-cert.sh device001 "Johns Phone"

# Send new .p12 to user
# User installs (replaces old one)
# Server accepts new cert automatically
```

## Scaling

| Devices | Time to Setup | Certificate Storage |
|---------|---------------|---------------------|
| 10 | 10 minutes | ~1 MB |
| 50 | 30 minutes | ~5 MB |
| 100 | 1 hour | ~10 MB |
| 500 | 3 hours | ~50 MB |

**Setup time breakdown:**
- Generate certificates: ~5 seconds per device
- Distribute .p12 files: ~2 minutes per device
- Device installation: ~2 minutes per device

**Automation recommended for 50+ devices**

## Backup

**Essential backup:**
```bash
# Backup critical files
tar -czf lumier-backup-$(date +%Y%m%d).tar.gz \
    certs/ca-key.pem \
    certs/ca-cert.pem \
    certs/server-key.pem \
    certs/server-cert.pem \
    device_bindings.db \
    proxies.txt

# Encrypt
gpg -c lumier-backup-$(date +%Y%m%d).tar.gz

# Store offsite
```

## Monitoring

### Dashboard

```
http://[SERVER]:8080

Shows:
- All devices
- Current IPs
- Connection counts
- Last seen
- Assigned proxies
- Rename devices
- Reassign proxies
```

### Database Queries

```bash
# View all devices
sqlite3 device_bindings.db "SELECT device_name, device_id, assigned_proxy FROM devices;"

# Connection history
sqlite3 device_bindings.db "SELECT * FROM connection_log WHERE device_id = 'device001' ORDER BY connected_at DESC LIMIT 10;"

# Devices by proxy
sqlite3 device_bindings.db "SELECT assigned_proxy, COUNT(*) FROM devices GROUP BY assigned_proxy;"
```

## Ports

- **1443**: TLS proxy server (devices connect here)
- **8080**: Web dashboard
- **53**: DNS server (requires root/sudo)

## Complete File Structure

```
/opt/lumierproxy/
  main.go
  proxies.txt
  device_bindings.db
  lumierproxy (binary)
  
  certs/
    ca-key.pem          (CRITICAL - backup!)
    ca-cert.pem
    server-key.pem
    server-cert.pem
    device001.p12
    device001-key.pem
    device001-cert.pem
    device002.p12
    ...
    
    downloads/          (for web download)
      device001.p12
      device002.p12
      ...
```

## Production Checklist

- [ ] CA certificate generated
- [ ] Server certificate generated
- [ ] Device certificates generated for all devices
- [ ] Proxies configured in proxies.txt
- [ ] Server tested with one device
- [ ] DNS leak prevention verified
- [ ] Dashboard accessible
- [ ] Certificates distributed to devices
- [ ] All devices installed certificates
- [ ] All devices configured proxy
- [ ] All devices tested
- [ ] CA key backed up securely offline
- [ ] Database backed up
- [ ] Monitoring set up
- [ ] Documentation provided to users

## User Instructions Template

**Email to send users:**

```
Subject: Lumier Proxy Certificate Installation

Hi [Name],

Please install your proxy certificate:

1. Download attached file: [device001.p12]
2. Tap to install
3. Password: lumier2024
4. Name: [Your Device Name]

Then configure Wi-Fi:
Settings → Wi-Fi → [Network] → Modify
Proxy: Manual
Hostname: 192.168.1.100
Port: 1443

Test: Visit google.com - should work!

Questions? Reply to this email.
```

## FAQ

**Q: Do I need to install anything on the server?**
A: Just OpenSSL and Go. Both are standard on Linux.

**Q: Do devices need an app?**
A: No. Certificate installed natively in Android.

**Q: What if device gets a new IP?**
A: No problem. Device identified by certificate, not IP.

**Q: What if device switches networks?**
A: No problem. Certificate works on any network.

**Q: Can one certificate be shared?**
A: Don't. Each device needs unique certificate for tracking.

**Q: How long does setup take per device?**
A: ~5 minutes total (certificate install + proxy config).

**Q: Can I automate this?**
A: Yes, use MDM for enterprise deployment.

## Support

**Logs:**
```bash
sudo journalctl -u lumierproxy -f
```

**Test connection:**
```bash
openssl s_client -connect localhost:1443
```

**Verify certificate:**
```bash
openssl x509 -in certs/device001-cert.pem -text -noout
```

---

You now have the most robust proxy system possible! 🎉

Survives everything:
✅ DHCP rotation
✅ Network changes
✅ Device roaming
✅ IP changes
✅ Short leases

All while maintaining:
✅ Perfect device identification
✅ No proxy mixing
✅ DNS leak prevention
✅ Cryptographic security
