# TLS Client Certificate Authentication Guide

## How It Works

### The Certificate Flow

```
1. Server Setup:
   - Generate Certificate Authority (CA)
   - Generate unique client certificate for each device
   - Configure proxy to require client certificates

2. Device Setup:
   - Install client certificate (.p12 file) on Android
   - Android automatically presents certificate when connecting

3. Connection:
   Device connects → TLS handshake → Device presents certificate
   → Server validates certificate → Extracts device ID from cert
   → Assigns/retrieves proxy for that device → Connection established
```

### Why This Works Perfectly

**Survives everything:**
- ✅ IP changes (DHCP rotation)
- ✅ Network switches (home/work/mobile)
- ✅ Device reboots
- ✅ App data clearing
- ✅ OS updates

**Cryptographically unique:**
- Each certificate has unique serial number
- Can't be duplicated accidentally
- Can be revoked if device lost/stolen

## Step-by-Step Implementation

### Phase 1: Certificate Generation (Server Side)

#### Step 1: Create Certificate Authority (CA)

This is your "master" certificate that signs all device certificates.

```bash
# Create directory for certificates
mkdir -p /opt/lumierproxy/certs
cd /opt/lumierproxy/certs

# Generate CA private key (keep this SECRET!)
openssl genrsa -aes256 -out ca-key.pem 4096

# You'll be prompted for a password - use something strong!
# Example: LumierCA_2024_SecurePassword

# Generate CA certificate (valid 10 years)
openssl req -new -x509 -days 3650 -key ca-key.pem -sha256 -out ca-cert.pem

# Fill in details:
# Country: US
# State: California
# City: San Francisco
# Organization: Lumier Proxy
# Common Name: Lumier Proxy CA
# Email: admin@yourcompany.com
```

**You now have:**
- `ca-key.pem` - CA private key (NEVER share this!)
- `ca-cert.pem` - CA public certificate (install on devices)

#### Step 2: Generate Device Certificates

Create a script to generate certificates for each device:

```bash
#!/bin/bash
# generate-device-cert.sh

DEVICE_ID=$1
DEVICE_NAME=$2

if [ -z "$DEVICE_ID" ] || [ -z "$DEVICE_NAME" ]; then
    echo "Usage: ./generate-device-cert.sh <device-id> <device-name>"
    echo "Example: ./generate-device-cert.sh device001 'Johns Phone'"
    exit 1
fi

echo "Generating certificate for $DEVICE_NAME (ID: $DEVICE_ID)"

# Generate device private key
openssl genrsa -out ${DEVICE_ID}-key.pem 2048

# Generate certificate signing request (CSR)
openssl req -new -key ${DEVICE_ID}-key.pem -out ${DEVICE_ID}-csr.pem \
    -subj "/C=US/ST=CA/L=SF/O=Lumier/CN=${DEVICE_ID}/emailAddress=${DEVICE_ID}@lumier.local"

# Sign with CA (valid 2 years)
openssl x509 -req -in ${DEVICE_ID}-csr.pem -CA ca-cert.pem -CAkey ca-key.pem \
    -CAcreateserial -out ${DEVICE_ID}-cert.pem -days 730 -sha256

# Create PKCS12 bundle (.p12) for Android
# This combines private key + certificate into one file
openssl pkcs12 -export -out ${DEVICE_ID}.p12 \
    -inkey ${DEVICE_ID}-key.pem \
    -in ${DEVICE_ID}-cert.pem \
    -certfile ca-cert.pem \
    -name "${DEVICE_NAME}" \
    -passout pass:lumier2024

# Note: Password is "lumier2024" - you can change this
# Device will need this password when installing

echo "✓ Generated certificates for ${DEVICE_NAME}"
echo "  Certificate: ${DEVICE_ID}.p12"
echo "  Password: lumier2024"
echo ""
echo "Transfer ${DEVICE_ID}.p12 to device and install it"

# Clean up intermediate files
rm ${DEVICE_ID}-csr.pem

# Set proper permissions
chmod 600 ${DEVICE_ID}-key.pem
chmod 644 ${DEVICE_ID}-cert.pem
chmod 644 ${DEVICE_ID}.p12
```

Save this as `/opt/lumierproxy/certs/generate-device-cert.sh` and make executable:

```bash
chmod +x /opt/lumierproxy/certs/generate-device-cert.sh
```

#### Step 3: Generate Certificates for All Devices

```bash
cd /opt/lumierproxy/certs

# Generate for device001
./generate-device-cert.sh device001 "Johns Phone"

# Generate for device002
./generate-device-cert.sh device002 "Marys Tablet"

# Generate for device003
./generate-device-cert.sh device003 "Warehouse Phone 1"

# Repeat for all devices...
```

**You now have for each device:**
- `device001.p12` - Install this on the device
- `device001-key.pem` - Keep on server (backup)
- `device001-cert.pem` - Keep on server (backup)

#### Step 4: Create Bulk Generation Script (Optional)

For 100+ devices:

```bash
#!/bin/bash
# bulk-generate-certs.sh

# Read from CSV file: device_id,device_name
# Example CSV:
# device001,Johns Phone
# device002,Marys Tablet
# device003,Warehouse Phone 1

while IFS=',' read -r device_id device_name; do
    echo "Processing: $device_name ($device_id)"
    ./generate-device-cert.sh "$device_id" "$device_name"
done < devices.csv

echo "✓ All certificates generated!"
echo "Transfer .p12 files to respective devices"
```

Create `devices.csv`:
```csv
device001,Johns Phone
device002,Marys Tablet
device003,Warehouse Phone 1
device004,Office Tablet
device005,Sales Phone 1
```

Run:
```bash
./bulk-generate-certs.sh
```

### Phase 2: Installing Certificates on Android Devices

#### Method 1: Manual Installation (Small Deployments)

**For each device:**

1. **Transfer .p12 file to device**
   - Email: Send `device001.p12` as attachment
   - USB: Copy via USB cable
   - Cloud: Upload to Google Drive, download on device
   - QR Code: Generate QR with download link
   - Local web server: Host files, download via browser

2. **Install certificate on Android**
   ```
   Settings → Security → Install from storage
   (or Settings → Security → Encryption & credentials → Install a certificate → VPN & app user certificate)
   
   Navigate to Downloads folder
   Select: device001.p12
   Enter password: lumier2024
   Name: Johns Phone (or device001)
   Credential use: VPN and apps
   Tap OK
   ```

3. **Verify installation**
   ```
   Settings → Security → Trusted credentials → User tab
   Should see: Johns Phone (or device001)
   ```

#### Method 2: QR Code Installation (Medium Deployments)

Generate QR codes for easy download:

```bash
#!/bin/bash
# generate-qr-codes.sh

# Install qrencode
# apt-get install qrencode

# Create web server directory
mkdir -p /opt/lumierproxy/certs/downloads

# For each device certificate
for p12file in *.p12; do
    device_id="${p12file%.p12}"
    
    # Copy to web directory
    cp "$p12file" /opt/lumierproxy/certs/downloads/
    
    # Generate QR code with download URL
    # Replace SERVER_IP with your actual server IP
    qrencode -o "${device_id}-qr.png" \
        "http://192.168.1.100:8080/certs/${p12file}"
    
    echo "✓ QR code for ${device_id}: ${device_id}-qr.png"
done
```

**Serve certificates via web server:**

Add to your main.go:
```go
// Add to web dashboard
http.Handle("/certs/", http.StripPrefix("/certs/", 
    http.FileServer(http.Dir("/opt/lumierproxy/certs/downloads"))))
```

**Device installation:**
1. Print or display QR code
2. User scans QR with camera app
3. Opens browser to download link
4. Downloads device001.p12
5. Android prompts to install
6. User enters password: lumier2024
7. Certificate installed!

#### Method 3: MDM Deployment (Large Deployments)

If you have Mobile Device Management (Google Workspace, Intune, etc.):

**Google Workspace:**
```
Admin Console → Devices → Mobile → Settings → Certificates
Upload: device001.p12
Password: lumier2024
Assign to: Specific device
```

**Microsoft Intune:**
```
Devices → Configuration profiles → Create profile
Platform: Android Enterprise
Profile type: PKCS certificate
Upload certificate and assign
```

#### Method 4: Email Distribution (Easiest for <50 devices)

```bash
#!/bin/bash
# email-certificates.sh

# Format: device_id,email,device_name
MAPPING="
device001,john@company.com,Johns Phone
device002,mary@company.com,Marys Tablet
device003,warehouse@company.com,Warehouse Phone 1
"

echo "$MAPPING" | while IFS=',' read -r device_id email device_name; do
    if [ -z "$device_id" ]; then continue; fi
    
    echo "Emailing certificate to $email for $device_name"
    
    # Using sendmail or mail command
    mail -s "Lumier Proxy Certificate - $device_name" \
         -a "${device_id}.p12" \
         "$email" << EOF
Hi,

Attached is your proxy certificate for: $device_name

Installation steps:
1. Download the attached ${device_id}.p12 file
2. Tap the file to install
3. Enter password: lumier2024
4. Name it: $device_name
5. Tap OK

Then configure your Wi-Fi proxy:
- Proxy: 192.168.1.100
- Port: 1443

Questions? Reply to this email.

Best regards,
IT Team
EOF

done
```

### Phase 3: Server Certificate Generation

The server also needs its own certificate for TLS:

```bash
cd /opt/lumierproxy/certs

# Generate server private key
openssl genrsa -out server-key.pem 2048

# Generate server certificate signing request
openssl req -new -key server-key.pem -out server-csr.pem \
    -subj "/C=US/ST=CA/L=SF/O=Lumier/CN=lumierproxy.local"

# Sign with CA (valid 2 years)
openssl x509 -req -in server-csr.pem -CA ca-cert.pem -CAkey ca-key.pem \
    -CAcreateserial -out server-cert.pem -days 730 -sha256

# Clean up
rm server-csr.pem

echo "✓ Server certificate generated"
```

### Phase 4: Android Configuration

#### Step 1: Install Client Certificate

After device has certificate installed (see Phase 2):

**Configure Wi-Fi Proxy:**
```
Settings → Wi-Fi → [Your Network] → Modify network

Advanced options:
  Proxy: Manual
  Proxy hostname: 192.168.1.100 (your server)
  Proxy port: 1443             ← Note: 1443, not 1080!
  
Optional DNS (for leak prevention):
  IP settings: Static
  DNS 1: 192.168.1.100
  DNS 2: 8.8.8.8
```

**Important Notes:**
- Port is **1443** (TLS proxy), not 1080
- No username/password needed
- Certificate automatically used by Android

#### Step 2: Test Connection

1. **Open browser** → Visit google.com
   - Should connect ✓

2. **Check proxy working**
   - Visit: https://whatismyipaddress.com
   - Should show proxy IP ✓

3. **Check DNS leak**
   - Visit: https://dnsleaktest.com
   - Should show proxy DNS location ✓

4. **Check dashboard**
   - Open: http://192.168.1.100:8080
   - Should see device listed ✓

### Phase 5: Running the Server

```bash
cd /opt/lumierproxy

# Ensure cert directory structure:
# certs/
#   ca-cert.pem
#   ca-key.pem
#   server-cert.pem
#   server-key.pem
#   device001.p12
#   device002.p12
#   ...

# Start server (requires sudo for DNS port 53)
sudo ./lumierproxy
```

**You should see:**
```
Starting Lumier Proxy v4.0 - TLS Certificate Edition
✓ Loaded CA certificate for client verification
✓ Loaded server certificate for TLS
Loaded 3 proxies
Loaded 0 existing devices
Starting DNS server on port 53
Starting web dashboard on http://localhost:8080
TLS proxy server listening on port 1443 (Client cert required)
```

## Complete Setup Example

### Example: 3 Devices Setup

```bash
# 1. Generate CA (once)
cd /opt/lumierproxy/certs
./generate-ca.sh

# 2. Generate server cert (once)
./generate-server-cert.sh

# 3. Generate device certificates
./generate-device-cert.sh device001 "Johns Phone"
./generate-device-cert.sh device002 "Marys Tablet"  
./generate-device-cert.sh device003 "Warehouse Phone"

# 4. You now have:
# device001.p12  → Send to John
# device002.p12  → Send to Mary
# device003.p12  → Send to Warehouse

# 5. Email certificates
./email-certificates.sh

# 6. Start server
cd /opt/lumierproxy
sudo ./lumierproxy
```

### On Each Android Device:

**John's Phone:**
1. Receive email with device001.p12
2. Download and tap to install
3. Enter password: lumier2024
4. Name: Johns Phone
5. Configure Wi-Fi proxy: 192.168.1.100:1443
6. Test - should work!

**Mary's Tablet:**
1. Receive email with device002.p12
2. Same installation process
3. Configure Wi-Fi proxy: 192.168.1.100:1443
4. Test - should work!

**Warehouse Phone:**
1. Receive email with device003.p12
2. Same installation process
3. Configure Wi-Fi proxy: 192.168.1.100:1443
4. Test - should work!

## How Devices Are Identified

```
Connection Flow:
1. Device connects to 192.168.1.100:1443
2. TLS handshake occurs
3. Server requests client certificate
4. Device presents device001.p12 certificate
5. Server reads Common Name (CN) from cert: "device001"
6. Server looks up device001 in database
7. If first time: Assign proxy1, save to database
8. If exists: Use existing proxy assignment
9. All traffic routes through assigned proxy
10. DNS queries also through assigned proxy
```

**Key advantage:**
- Device can connect from ANY IP address
- Device can switch networks
- Device can roam between Wi-Fi hotspots
- Device ALWAYS identified as "device001"
- Device ALWAYS uses same proxy

## Troubleshooting

### Issue: "Certificate not trusted"

**Cause**: CA certificate not installed on device

**Fix**:
1. Install CA certificate first:
   - Transfer ca-cert.pem to device
   - Settings → Security → Install from storage
   - Select ca-cert.pem
   - Name: "Lumier Proxy CA"
   - Credential use: VPN and apps
2. Then install device certificate

### Issue: "No certificate found"

**Cause**: Device certificate not installed

**Fix**: Verify certificate installed:
```
Settings → Security → Trusted credentials → User tab
Should see: Johns Phone (or device001)
```

### Issue: Connection fails immediately

**Cause**: Server certificate mismatch or expired

**Fix**:
1. Check server logs for TLS errors
2. Verify server-cert.pem is valid:
   ```bash
   openssl x509 -in certs/server-cert.pem -text -noout
   ```
3. Check dates are valid (not expired)

### Issue: "Connection reset" or "SSL error"

**Cause**: Client certificate not accepted by server

**Fix**:
1. Verify client cert signed by correct CA
2. Check server logs: "TLS handshake failed"
3. Regenerate certificate if needed

### Issue: Device shows as "Unknown" in dashboard

**Cause**: Certificate CN doesn't match expected format

**Fix**: Ensure device cert generated with correct CN:
```bash
openssl x509 -in certs/device001-cert.pem -noout -subject
# Should show: CN=device001
```

## Security Considerations

### Certificate Security

**Private Keys:**
- CA key (ca-key.pem): **CRITICAL** - keep encrypted and backed up
- Server key (server-key.pem): Keep secure on server
- Device keys (device001-key.pem): Embedded in .p12, protected by password

**Best Practices:**
1. Use strong password for CA key
2. Use unique password for each device .p12 (or at least per batch)
3. Back up CA key offline
4. Revoke certificates if device lost/stolen

### Certificate Revocation

If device is lost or stolen:

```bash
# 1. Create revocation list
openssl ca -revoke certs/device001-cert.pem \
    -keyfile certs/ca-key.pem \
    -cert certs/ca-cert.pem

# 2. Generate CRL (Certificate Revocation List)
openssl ca -gencrl -out certs/crl.pem \
    -keyfile certs/ca-key.pem \
    -cert certs/ca-cert.pem

# 3. Update server to check CRL (requires code modification)
```

Or simpler: Delete device from database:
```sql
DELETE FROM devices WHERE device_id = 'device001';
```

Server will refuse new connections from that certificate.

## Certificate Renewal

Certificates expire after 2 years. To renew:

```bash
# For device certificate expiring soon
cd /opt/lumierproxy/certs

# Generate new certificate with same device ID
./generate-device-cert.sh device001 "Johns Phone"

# This creates new device001.p12
# Send to user, they install (replaces old one)

# Server automatically accepts new cert (same device ID)
```

## Backup Strategy

**Critical Files to Backup:**
```
/opt/lumierproxy/
  certs/
    ca-key.pem          ← CRITICAL! Backup securely
    ca-cert.pem         ← Backup
    server-key.pem      ← Backup
    server-cert.pem     ← Backup
    device*-key.pem     ← Optional (can regenerate)
    device*-cert.pem    ← Optional (can regenerate)
  device_bindings.db    ← Important (device assignments)
  proxies.txt           ← Backup
```

**Backup Commands:**
```bash
# Encrypted backup
tar -czf lumier-backup-$(date +%Y%m%d).tar.gz \
    /opt/lumierproxy/certs/ca-*.pem \
    /opt/lumierproxy/certs/server-*.pem \
    /opt/lumierproxy/device_bindings.db \
    /opt/lumierproxy/proxies.txt

# Encrypt with GPG
gpg -c lumier-backup-$(date +%Y%m%d).tar.gz

# Store encrypted file offsite
```

## Summary

**What You Get:**
✅ Perfect device identification (certificate-based)
✅ Survives all network changes
✅ No dependency on IP or MAC address
✅ No DHCP configuration needed
✅ DNS leak prevention built-in
✅ Cryptographically secure
✅ Easy to revoke if device lost

**What Users Do:**
1. Install certificate (one-time, 2 minutes)
2. Configure proxy hostname:port (one-time, 1 minute)
3. Done! Works forever

**What You Do:**
1. Generate certificates for all devices (automated)
2. Distribute .p12 files (email/download)
3. Run server
4. Monitor dashboard

This is the most robust solution for your DHCP rotation / network switching environment!

