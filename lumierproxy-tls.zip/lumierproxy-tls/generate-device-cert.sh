#!/bin/bash
# generate-device-cert.sh - Generate client certificate for a device

set -e

DEVICE_ID=$1
DEVICE_NAME=$2
PASSWORD=${3:-lumier2024}  # Default password

if [ -z "$DEVICE_ID" ] || [ -z "$DEVICE_NAME" ]; then
    echo "Usage: ./generate-device-cert.sh <device-id> <device-name> [password]"
    echo ""
    echo "Examples:"
    echo "  ./generate-device-cert.sh device001 'Johns Phone'"
    echo "  ./generate-device-cert.sh device002 'Marys Tablet' 'custom_password'"
    echo ""
    exit 1
fi

cd certs

# Check if CA exists
if [ ! -f "ca-key.pem" ] || [ ! -f "ca-cert.pem" ]; then
    echo "❌ Error: CA certificate not found!"
    echo "Run ./generate-ca.sh first"
    exit 1
fi

echo "Generating certificate for: $DEVICE_NAME (ID: $DEVICE_ID)"
echo ""

# Check if device cert already exists
if [ -f "${DEVICE_ID}.p12" ]; then
    echo "⚠️  Certificate for $DEVICE_ID already exists"
    read -p "Regenerate? (yes/NO): " confirm
    if [ "$confirm" != "yes" ]; then
        echo "Skipped."
        exit 0
    fi
    echo ""
fi

# Generate device private key
openssl genrsa -out ${DEVICE_ID}-key.pem 2048

# Generate certificate signing request (CSR)
# CN (Common Name) = device ID, which server uses for identification
openssl req -new -key ${DEVICE_ID}-key.pem -out ${DEVICE_ID}-csr.pem \
    -subj "/C=US/ST=CA/L=SF/O=Lumier/CN=${DEVICE_ID}/emailAddress=${DEVICE_ID}@lumier.local"

# Sign with CA (valid 2 years)
openssl x509 -req -in ${DEVICE_ID}-csr.pem -CA ca-cert.pem -CAkey ca-key.pem \
    -CAcreateserial -out ${DEVICE_ID}-cert.pem -days 730 -sha256

# Create PKCS12 bundle (.p12) for Android
# This combines private key + certificate + CA cert into one file
openssl pkcs12 -export -out ${DEVICE_ID}.p12 \
    -inkey ${DEVICE_ID}-key.pem \
    -in ${DEVICE_ID}-cert.pem \
    -certfile ca-cert.pem \
    -name "${DEVICE_NAME}" \
    -passout pass:${PASSWORD}

# Clean up intermediate files
rm ${DEVICE_ID}-csr.pem

# Set proper permissions
chmod 600 ${DEVICE_ID}-key.pem
chmod 644 ${DEVICE_ID}-cert.pem
chmod 644 ${DEVICE_ID}.p12

# Create downloads directory if it doesn't exist
mkdir -p downloads
cp ${DEVICE_ID}.p12 downloads/

echo "========================================="
echo "✓ Certificate Generated!"
echo "========================================="
echo ""
echo "Device: $DEVICE_NAME"
echo "ID: $DEVICE_ID"
echo "Certificate: ${DEVICE_ID}.p12"
echo "Password: $PASSWORD"
echo ""
echo "Files created:"
echo "  ${DEVICE_ID}.p12       - Install this on the device"
echo "  ${DEVICE_ID}-key.pem   - Device private key (backup)"
echo "  ${DEVICE_ID}-cert.pem  - Device certificate (backup)"
echo ""
echo "Also copied to: downloads/${DEVICE_ID}.p12"
echo ""
echo "Installation instructions for device:"
echo "1. Transfer ${DEVICE_ID}.p12 to device (email, USB, download)"
echo "2. On Android: Settings → Security → Install from storage"
echo "3. Select ${DEVICE_ID}.p12"
echo "4. Enter password: $PASSWORD"
echo "5. Name: $DEVICE_NAME"
echo "6. Tap OK"
echo ""
echo "Then configure Wi-Fi proxy:"
echo "  Hostname: [your server IP]"
echo "  Port: 1443"
echo ""
