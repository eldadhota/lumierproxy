# LumierProxy v3.2 - Enterprise Proxy Management Server

## New Features in v3.2

### 1. Device Health Monitoring
- Real-time health scores (0-100) for each connected device
- Automatic proxy verification every 10 minutes
- Health status: healthy, degraded, unhealthy, offline, unverified
- Success rate tracking
- Consecutive error counting

### 2. Debounced Save System
- Prevents disk thrashing under heavy load
- Saves batched every 5 seconds instead of per-change
- Atomic writes using temp file + rename
- Thread-safe deep copies of data structures

### 3. Audit Logging
- Tracks all security-relevant events
- Categories: auth, device, proxy, session, config
- Configurable retention period (default 30 days)
- Filterable by category in dashboard

### 4. New Dashboard Pages
- `/device-health` - Device health overview with verification controls
- `/audit` - Security audit log viewer

### 5. New API Endpoints
- `GET /api/device-health` - All device health data
- `GET /api/device-health-stats` - Summary statistics
- `POST /api/verify-device-proxy` - Manual verification trigger
- `GET /api/audit-logs` - Audit log retrieval

## Zero-Downtime Deployment

### Using Tailscale
Since you have Tailscale installed, you can deploy updates without interrupting users:

1. SSH to your server via Tailscale:
   ```bash
   ssh root@your-tailscale-hostname
   ```

2. Use the deploy script:
   ```bash
   # Set your Tailscale hostname
   export REMOTE_HOST="your-tailscale-ip-or-hostname"
   ./deploy.sh
   ```

### Manual Deployment
```bash
# Build locally
GOOS=linux GOARCH=amd64 go build -o lumierproxy .

# Upload via Tailscale
scp lumierproxy root@your-tailscale-hostname:/opt/lumierproxy/

# SSH and restart
ssh root@your-tailscale-hostname
cd /opt/lumierproxy
chmod +x lumierproxy
systemctl restart lumierproxy
```

### First-Time Installation
```bash
# Create directory
mkdir -p /opt/lumierproxy
cd /opt/lumierproxy

# Copy files
cp main.go pages.go ./
go build -o lumierproxy .

# Install systemd service
cp lumierproxy.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable lumierproxy
systemctl start lumierproxy
```

## Configuration

### Environment Variables
| Variable | Default | Description |
|----------|---------|-------------|
| `PROXY_PORT` | 8888 | Port for proxy connections |
| `DASHBOARD_PORT` | 8080 | Port for web dashboard |
| `REQUIRE_REGISTER` | true | Require app registration |
| `BIND_ADDR` | 0.0.0.0 | Bind address |
| `ALLOW_IP_FALLBACK` | false | Allow IP-based device lookup |

### System Settings (via Dashboard)
- Session timeout (hours)
- Device health check interval (minutes)
- Max consecutive errors before marking unhealthy
- Audit log retention (days)
- Traffic retention (days)

## File Structure
```
/opt/lumierproxy/
├── lumierproxy          # Binary
├── proxies.txt          # Proxy list
├── device_data.json     # Persistent data
└── device_data.json.tmp # Temp file for atomic writes
```

## Debouncer Explanation

The save debouncer prevents disk I/O overload when many devices are active:

**Before (Problem):**
```go
// Called on every change - could be 100s of times per second!
go s.savePersistentData()
```

**After (Solution):**
```go
// Signal that save is needed (non-blocking)
func (s *ProxyServer) requestSave() {
    select {
    case s.saveChan <- struct{}{}:
    default: // Already pending, skip
    }
}

// Background worker - saves at most once every 5 seconds
func (s *ProxyServer) saveWorker() {
    ticker := time.NewTicker(5 * time.Second)
    needsSave := false
    for {
        select {
        case <-s.saveChan:
            needsSave = true  // Mark that save is needed
        case <-ticker.C:
            if needsSave {
                s.doSave()    // Actually save
                needsSave = false
            }
        }
    }
}
```

**Benefits:**
- Under heavy load: Max 12 disk writes per minute instead of thousands
- Changes are batched together
- Non-blocking - callers don't wait for disk I/O
- Graceful shutdown saves pending changes

## API Reference

### Device Health
```bash
# Get all device health
curl http://server:8080/api/device-health

# Get health stats
curl http://server:8080/api/device-health-stats

# Manually verify a device
curl -X POST http://server:8080/api/verify-device-proxy \
  -H "Content-Type: application/json" \
  -d '{"username":"device123"}'
```

### Audit Logs
```bash
# Get all audit logs
curl http://server:8080/api/audit-logs

# Filter by category
curl "http://server:8080/api/audit-logs?category=auth&limit=50"
```

## Troubleshooting

### Server won't start
```bash
# Check logs
journalctl -u lumierproxy -f

# Check if ports are in use
ss -tlnp | grep -E "8080|8888"
```

### Devices showing unhealthy
- Check proxy connection in dashboard
- Manually verify: Dashboard → Device Health → Verify button
- Check consecutive errors count

### High CPU/Memory
- Check goroutine count in Monitoring page
- The debouncer should keep goroutine count stable
- If rising: restart service
