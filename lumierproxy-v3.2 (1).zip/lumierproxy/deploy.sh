#!/bin/bash
# LumierProxy Zero-Downtime Deployment Script
# Designed for use with Tailscale for remote server access

set -e

# Configuration
REMOTE_USER="${REMOTE_USER:-root}"
REMOTE_HOST="${REMOTE_HOST:-your-server}"  # Set to your Tailscale IP/hostname
REMOTE_DIR="${REMOTE_DIR:-/opt/lumierproxy}"
SERVICE_NAME="lumierproxy"
BINARY_NAME="lumierproxy"

echo "🚀 LumierProxy Zero-Downtime Deployment"
echo "========================================"

# Build the binary
echo "📦 Building binary..."
GOOS=linux GOARCH=amd64 go build -o $BINARY_NAME .

# Create deployment package
echo "📁 Creating deployment package..."
tar -czf deploy.tar.gz $BINARY_NAME proxies.txt 2>/dev/null || tar -czf deploy.tar.gz $BINARY_NAME

# Upload to server
echo "⬆️  Uploading to $REMOTE_HOST..."
scp deploy.tar.gz $REMOTE_USER@$REMOTE_HOST:/tmp/

# Deploy with zero downtime
echo "🔄 Deploying with graceful restart..."
ssh $REMOTE_USER@$REMOTE_HOST << 'REMOTESCRIPT'
cd /tmp
tar -xzf deploy.tar.gz

# Backup current binary
if [ -f /opt/lumierproxy/lumierproxy ]; then
    cp /opt/lumierproxy/lumierproxy /opt/lumierproxy/lumierproxy.backup
fi

# Move new binary
mv lumierproxy /opt/lumierproxy/
chmod +x /opt/lumierproxy/lumierproxy

# Copy proxies.txt if included
if [ -f proxies.txt ]; then
    mv proxies.txt /opt/lumierproxy/
fi

# Graceful restart (systemd will handle connections)
systemctl restart lumierproxy

# Wait and verify
sleep 3
if systemctl is-active --quiet lumierproxy; then
    echo "✅ Deployment successful!"
    systemctl status lumierproxy --no-pager
else
    echo "❌ Deployment failed, rolling back..."
    cp /opt/lumierproxy/lumierproxy.backup /opt/lumierproxy/lumierproxy
    systemctl restart lumierproxy
    exit 1
fi

# Cleanup
rm -f /tmp/deploy.tar.gz /tmp/lumierproxy /tmp/proxies.txt
REMOTESCRIPT

# Cleanup local files
rm -f deploy.tar.gz $BINARY_NAME

echo ""
echo "✅ Deployment complete!"
echo "📊 Dashboard: http://$REMOTE_HOST:8080"
